//
//  SecondViewController.h
//  Chapter1-2
//
//  Created by TangQiao on 5/2/14.
//  Copyright (c) 2014 TangQiao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FirstViewController.h"

@interface SecondViewController : UIViewController

@property (strong, nonatomic) FirstViewController *firstViewController;

@end
