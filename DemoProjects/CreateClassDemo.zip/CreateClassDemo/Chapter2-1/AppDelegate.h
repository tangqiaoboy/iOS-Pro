//
//  AppDelegate.h
//  Chapter2-1
//
//  Created by TangQiao on 5/2/14.
//  Copyright (c) 2014 TangQiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
