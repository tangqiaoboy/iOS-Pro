//
//  main.m
//  FlurryUsageSample
//
//  Created by TangQiao on 13-10-24.
//  Copyright (c) 2013年 TangQiao. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
