//
//  CoreTextLinkData.m
//  CoreTextDemo
//
//  Created by TangQiao on 13-12-22.
//  Copyright (c) 2013年 TangQiao. All rights reserved.
//

#import "CoreTextLinkData.h"

@implementation CoreTextLinkData

@end
