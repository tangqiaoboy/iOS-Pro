//
//  AppDelegate.h
//  FlurryUsageSample
//
//  Created by TangQiao on 13-10-24.
//  Copyright (c) 2013年 TangQiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
