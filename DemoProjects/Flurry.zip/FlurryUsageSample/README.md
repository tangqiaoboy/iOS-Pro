This is a demo project for using flurry.
