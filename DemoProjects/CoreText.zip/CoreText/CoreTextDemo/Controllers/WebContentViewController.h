//
//  WebContentViewController.h
//  CoreTextDemo
//
//  Created by TangQiao on 13-12-22.
//  Copyright (c) 2013年 TangQiao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebContentViewController : UIViewController

@property (strong, nonatomic) NSString *urlTitle;
@property (strong, nonatomic) NSString *url;

@end
